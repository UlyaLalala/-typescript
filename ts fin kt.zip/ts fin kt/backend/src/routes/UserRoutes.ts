import { Router } from 'express';
import { sign, check, create, addPet, addColors, getAllUsers } from '../controllers/UserController';

const router = Router();

router.post('/sign', sign);
router.post('/check', check);
router.post('/create', create);
router.post('/pet', addPet);
router.post('/colors', addColors);
router.get('/users', getAllUsers); 

export default router;