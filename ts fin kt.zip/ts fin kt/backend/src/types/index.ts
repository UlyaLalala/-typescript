export interface Pet {
    name: string;
}


export interface Color {
    name: string;
}


export interface User {
    id: number;
    name: string;
    lastName: string | null;
    pets: Pet[];
    colors: Color[];
}


export interface SignResponse {
    id: number;
    message: string;
}

export interface CheckResponse {
    exists: boolean;
    id?: number;
    message: string;
}

export interface CreateResponse {
    message: string;
    user: User;
}

export interface ErrorResponse {
    error: string;
}