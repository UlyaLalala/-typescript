import { Request, Response } from 'express';
import { User, Pet, Color, ErrorResponse } from '../types';


let users: User[] = [];
let nextId: number = 1;

// 1. POST /sign - добавить имя
export const sign = (req: Request, res: Response) => {
    const { name } = req.body;

    
    if (!name || name.trim() === '') {
        const error: ErrorResponse = { error: 'Имя обязательно!' };
        return res.status(400).json(error);
    }

    const trimmedName = name.trim();

    
    const existingUser = users.find(u => u.name === trimmedName);
    if (existingUser) {
        return res.status(400).json({ error: 'Такое имя уже существует!' });
    }

    
    const newUser: User = {
        id: nextId++,
        name: trimmedName,
        lastName: null,
        pets: [],
        colors: []
    };

    users.push(newUser);

    res.json({
        id: newUser.id,
        message: ` Пользователь "${newUser.name}" добавлен! Его номер: ${newUser.id}`
    });
};


export const check = (req: Request, res: Response) => {
    const { name } = req.body;

    if (!name || name.trim() === '') {
        return res.status(400).json({ error: 'Имя обязательно!' });
    }

    const trimmedName = name.trim();
    const user = users.find(u => u.name === trimmedName);

    if (user) {
        res.json({
            exists: true,
            id: user.id,
            message: `Пользователь "${user.name}" найден! номер: ${user.id}`
        });
    } else {
        res.json({
            exists: false,
            message: `Пользователь с именем "${trimmedName}" не найден`
        });
    }
};


export const create = (req: Request, res: Response) => {
    const { name, lastName } = req.body;

    if (!name || name.trim() === '') {
        return res.status(400).json({ error: 'Имя обязательно!' });
    }

    if (!lastName || lastName.trim() === '') {
        return res.status(400).json({ error: 'Фамилия обязательна!' });
    }

    const trimmedName = name.trim();
    const trimmedLastName = lastName.trim();

    
    const existingUser = users.find(u => u.name === trimmedName);

    if (existingUser) {
        
        existingUser.lastName = trimmedLastName;
        res.json({
            message: `Пользователю "${existingUser.name}" добавлена фамилия "${existingUser.lastName}"`,
            user: existingUser
        });
    } else {
        
        const newUser: User = {
            id: nextId++,
            name: trimmedName,
            lastName: trimmedLastName,
            pets: [],
            colors: []
        };
        users.push(newUser);
        res.json({
            message: `Создан новый пользователь: ${newUser.name} ${newUser.lastName} (ID: ${newUser.id})`,
            user: newUser
        });
    }
};

export const addPet = (req: Request, res: Response) => {
    const { id, petName } = req.body;

    if (!id || typeof id !== 'number') {
        return res.status(400).json({ error: 'ID должен быть числом!' });
    }

    if (!petName || petName.trim() === '') {
        return res.status(400).json({ error: 'Название животного обязательно!' });
    }

    const user = users.find(u => u.id === id);

    if (!user) {
        return res.status(404).json({ error: `Пользователь с ID ${id} не найден!` });
    }

    const newPet: Pet = { name: petName.trim() };
    user.pets.push(newPet);

    res.json({
        message: `🐕 Пользователю "${user.name}" добавлено животное: ${petName}`,
        user: user
    });
};

export const addColors = (req: Request, res: Response) => {
    const { id, colors } = req.body;

    if (!id || typeof id !== 'number') {
        return res.status(400).json({ error: 'ID должен быть числом!' });
    }

    if (!Array.isArray(colors) || colors.length === 0) {
        return res.status(400).json({ error: 'Цвета должны быть массивом!' });
    }

    const user = users.find(u => u.id === id);

    if (!user) {
        return res.status(404).json({ error: `Пользователь с ID ${id} не найден!` });
    }

    // Добавляем цвета
    colors.forEach((color: string) => {
        if (color && color.trim()) {
            const newColor: Color = { name: color.trim() };
            user.colors.push(newColor);
        }
    });

    res.json({
        message: `🎨 Пользователю "${user.name}" добавлены цвета: ${colors.join(', ')}`,
        user: user
    });
};

export const getAllUsers = (req: Request, res: Response) => {
    res.json(users);
};