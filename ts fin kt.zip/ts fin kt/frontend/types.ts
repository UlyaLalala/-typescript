export interface Pet {
    name: string;
}

export interface Color {
    name: string;
}

export interface User {
    id: number;
    name: string;
    lastName: string | null;
    pets: Pet[];
    colors: Color[];
}