import React, { useState } from 'react';
import axios from 'axios';
import { User } from './types';
import './app.css';

const API_URL = 'http://localhost:3000/api';

function App() {
    // Состояния для форм
    const [signName, setSignName] = useState('');
    const [checkName, setCheckName] = useState('');
    const [createName, setCreateName] = useState('');
    const [createLastName, setCreateLastName] = useState('');
    const [petId, setPetId] = useState<string>('');
    const [petName, setPetName] = useState('');
    const [colorsId, setColorsId] = useState<string>('');
    const [colorsInput, setColorsInput] = useState('');
    
    // Состояния для результатов
    const [response, setResponse] = useState('');
    const [error, setError] = useState('');
    const [users, setUsers] = useState<User[]>([]);

    // 1. Добавить имя
    const handleSign = async () => {
        setError('');
        try {
            const res = await axios.post(`${API_URL}/sign`, { name: signName });
            setResponse(res.data.message);
            setSignName('');
        } catch (err: any) {
            setError(err.response?.data?.error || 'Ошибка запроса');
        }
    };

    // 2. Проверить имя
    const handleCheck = async () => {
        setError('');
        try {
            const res = await axios.post(`${API_URL}/check`, { name: checkName });
            setResponse(res.data.message);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Ошибка запроса');
        }
    };

    // 3. Добавить имя и фамилию
    const handleCreate = async () => {
        setError('');
        try {
            const res = await axios.post(`${API_URL}/create`, { 
                name: createName, 
                lastName: createLastName 
            });
            setResponse(res.data.message);
            setCreateName('');
            setCreateLastName('');
        } catch (err: any) {
            setError(err.response?.data?.error || 'Ошибка запроса');
        }
    };

    // 4. Добавить животное
    const handleAddPet = async () => {
        setError('');
        try {
            const res = await axios.post(`${API_URL}/pet`, { 
                id: Number(petId), 
                petName: petName 
            });
            setResponse(res.data.message);
            setPetId('');
            setPetName('');
        } catch (err: any) {
            setError(err.response?.data?.error || 'Ошибка запроса');
        }
    };

    // 5. Добавить цвета
    const handleAddColors = async () => {
        setError('');
        try {
            const colorsArray = colorsInput.split(',').map(c => c.trim());
            const res = await axios.post(`${API_URL}/colors`, { 
                id: Number(colorsId), 
                colors: colorsArray 
            });
            setResponse(res.data.message);
            setColorsId('');
            setColorsInput('');
        } catch (err: any) {
            setError(err.response?.data?.error || 'Ошибка запроса');
        }
    };

    // Получить всех пользователей
    const handleGetUsers = async () => {
        setError('');
        try {
            const res = await axios.get<User[]>(`${API_URL}/users`);
            setUsers(res.data);
            setResponse(`Загружено ${res.data.length} пользователей`);
        } catch (err: any) {
            setError(err.response?.data?.error || 'Ошибка запроса');
        }
    };

    return (
        <div className="container">
            <h1>пользователи</h1>
            
            {error && <div className="error">{error}</div>}
            {response && <div className="success">{response}</div>}

            <div className="grid">
                {/* 1. /sign */}
                <div className="card">
                    <h2>Добавить имя</h2>
                    <input 
                        placeholder="Имя" 
                        value={signName}
                        onChange={(e) => setSignName(e.target.value)}
                    />
                    <button onClick={handleSign}>Отправить</button>
                </div>

                {/* 2. /check */}
                <div className="card">
                    <h2>Проверить имя</h2>
                    <input 
                        placeholder="Имя" 
                        value={checkName}
                        onChange={(e) => setCheckName(e.target.value)}
                    />
                    <button onClick={handleCheck}>Проверить</button>
                </div>

                {/* 3. /create */}
                <div className="card">
                    <h2>Добавить имя и фамилию</h2>
                    <input 
                        placeholder="Имя" 
                        value={createName}
                        onChange={(e) => setCreateName(e.target.value)}
                    />
                    <input 
                        placeholder="Фамилия" 
                        value={createLastName}
                        onChange={(e) => setCreateLastName(e.target.value)}
                    />
                    <button onClick={handleCreate}>Создать</button>
                </div>

                {/* 4. /pet */}
                <div className="card">
                    <h2>Добавить животное</h2>
                    <input 
                        type="number"
                        placeholder="ID пользователя" 
                        value={petId}
                        onChange={(e) => setPetId(e.target.value)}
                    />
                    <input 
                        placeholder="Животное" 
                        value={petName}
                        onChange={(e) => setPetName(e.target.value)}
                    />
                    <button onClick={handleAddPet}>Добавить</button>
                </div>

                {/* 5. /colors */}
                <div className="card">
                    <h2>Добавить цвета</h2>
                    <input 
                        type="number"
                        placeholder="ID пользователя" 
                        value={colorsId}
                        onChange={(e) => setColorsId(e.target.value)}
                    />
                    <input 
                        placeholder="Цвета (красный, синий)" 
                        value={colorsInput}
                        onChange={(e) => setColorsInput(e.target.value)}
                    />
                    <button onClick={handleAddColors}>Добавить</button>
                </div>

                {/* Показать всех */}
                <div className="card">
                    <h2>Все пользователи</h2>
                    <button onClick={handleGetUsers}>Показать</button>
                </div>
            </div>

            {/* Таблица пользователей */}
            {users.length > 0 && (
                <div className="users-table">
                    <h2>Список пользователей</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Имя</th>
                                <th>Фамилия</th>
                                <th>Животные</th>
                                <th>Цвета</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => (
                                <tr key={user.id}>
                                    <td>{user.id}</td>
                                    <td>{user.name}</td>
                                    <td>{user.lastName || '-'}</td>
                                    <td>{user.pets.map(p => p.name).join(', ') || '-'}</td>
                                    <td>{user.colors.map(c => c.name).join(', ') || '-'}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}

export default App;