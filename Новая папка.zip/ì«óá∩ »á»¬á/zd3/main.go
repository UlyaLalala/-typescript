package main

import "fmt"

// reverseString переворачивает строку, корректно работая с Unicode
func reverseString(s string) string {
	// Преобразуем строку в срез рун (rune = int32 = один Unicode-символ)
	runes := []rune(s)

	// Меняем местами символы с двух концов к центру
	for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
		runes[i], runes[j] = runes[j], runes[i]
	}

	return string(runes)
}

func main() {
	input := "главрыба — абырвалг"
	fmt.Println(reverseString(input))
	// Ожидаемый результат: "главрыба — абырвалг" (перевёрнутый)
}