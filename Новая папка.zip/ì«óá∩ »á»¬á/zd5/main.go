package main

import (
	"fmt"
	"strings"
)

func hasUniqueChars(s string) bool {
	// Приводим строку к нижнему регистру — условие регистронезависимости
	s = strings.ToLower(s)

	// Карта как множество: какие символы мы уже видели
	seen := make(map[rune]bool)

	for _, char := range s {
		if seen[char] {
			return false // Символ уже встречался — не уникален
		}
		seen[char] = true
	}

	return true // Все символы уникальны
}

func main() {
	fmt.Println(hasUniqueChars("abcd"))      // true
	fmt.Println(hasUniqueChars("abCdefAaf")) // false
	fmt.Println(hasUniqueChars("aabcd"))     // false
}