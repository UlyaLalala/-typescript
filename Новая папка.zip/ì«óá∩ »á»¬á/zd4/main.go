package main

import (
	"fmt"
	"strings"
)

func reverseWords(s string) string {
	// Разбиваем строку по пробелам (Fields сам убирает лишние пробелы)
	words := strings.Fields(s)

	// Переворачиваем срез слов
	for i, j := 0, len(words)-1; i < j; i, j = i+1, j-1 {
		words[i], words[j] = words[j], words[i]
	}

	// Собираем обратно через пробел
	return strings.Join(words, " ")
}

func main() {
	input := "snow dog sun"
	fmt.Println(reverseWords(input)) // Выведет: sun dog snow
}