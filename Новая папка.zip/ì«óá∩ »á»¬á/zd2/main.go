package main

import (
	"fmt"
	"math"
)

func main() {
	temps := []float64{-25.4, -27.0, 13.0, 19.0, 15.5, 24.5, -21.0, 32.5}

	// Карта: ключ — группа (int), значение — срез температур ([]float64)
	groups := make(map[int][]float64)

	for _, t := range temps {
		// math.Floor корректно округляет вниз, в том числе для отрицательных чисел
		// -25.4 / 10 = -2.54 -> Floor = -3 -> * 10 = -30
		// -21.0 / 10 = -2.10 -> Floor = -3 -> * 10 = -30
		key := int(math.Floor(t/10.0)) * 10
		groups[key] = append(groups[key], t)
	}

	// Вывод
	for group, values := range groups {
		fmt.Printf("%d:%v\n", group, values)
	}
}