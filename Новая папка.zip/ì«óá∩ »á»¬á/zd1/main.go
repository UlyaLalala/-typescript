package main

import (
	"fmt"
	"sync"
)

func main() {
	numbers := []int{2, 4, 6, 8, 10}

	var wg sync.WaitGroup
	
	results := make(chan int, len(numbers))

	for _, num := range numbers {
		wg.Add(1) 
		go func(n int) {
			defer wg.Done() 
			results <- n * n 
		}(num)
	}

	go func() {
		wg.Wait()
		close(results)
	}()

	for res := range results {
		fmt.Println(res)
	}
}