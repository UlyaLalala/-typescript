const express = require("express");
const mysql = require("mysql2");
const app = express();

app.use(express.json());
app.use(express.static("public"));

const connection = mysql.createConnection({
    host: "5.129.248.204",
    port: "40294",
    user: "24V2_Ufimtseva",
    password: "Ufim24!V2",
    database: "db_24V2_Ufimtseva"
});

connection.connect((err) => {
    if (err) {
        console.log("Ошибка подключения:", err.message);
    } else {
        console.log("Подключение к БД успешно!");
    }
});

// 1. Получить все товары (напитки)
app.get("/api/products", (req, res) => {
    const sql = `
        SELECT p.id, p.name, p.price, p.description, p.image_url, c.name AS category
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE p.is_available = 1
    `;
    
    connection.query(sql, (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 2. Получить одну категорию товаров
app.get("/api/categories/:id", (req, res) => {
    const categoryId = req.params.id;
    const sql = `
        SELECT p.id, p.name, p.price, p.description
        FROM products p
        WHERE p.category_id = ? AND p.is_available = 1
    `;
    
    connection.query(sql, [categoryId], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 3. Регистрация пользователя
app.post("/api/register", (req, res) => {
    const { username, email, password, phone, address } = req.body;
    
    const sql = `
        INSERT INTO users (username, email, password, phone, address)
        VALUES (?, ?, ?, ?, ?)
    `;
    
    connection.query(sql, [username, email, password, phone, address], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ id: results.insertId, message: "Регистрация прошла успешно!" });
        }
    });
});

// 4. Авторизация пользователя
app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    
    const sql = `SELECT * FROM users WHERE username = ? AND password = ?`;
    
    connection.query(sql, [username, password], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else if (results.length === 0) {
            res.status(401).json({ error: "Неверное имя или пароль" });
        } else {
            const user = results[0];
            res.json({ 
                id: user.id, 
                username: user.username,
                email: user.email,
                phone: user.phone || '',
                address: user.address || '',
                message: "Вход выполнен!"
            });
        }
    });
});

// 5. Создать заказ
app.post("/api/orders", (req, res) => {
    const { user_id, items, total, address } = req.body;
    
    // Сначала создаём заказ
    const orderSql = `
        INSERT INTO orders (user_id, total_amount, delivery_address, status)
        VALUES (?, ?, ?, 'pending')
    `;
    
    connection.query(orderSql, [user_id, total, address], (err, orderResult) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        const orderId = orderResult.insertId;
        
        // Добавляем товары в заказ
        const itemSql = `
            INSERT INTO order_items (order_id, product_id, quantity, price)
            VALUES ?
        `;
        
        const itemValues = items.map(item => [orderId, item.product_id, item.quantity, item.price]);
        
        connection.query(itemSql, [itemValues], (err2) => {
            if (err2) {
                res.status(500).json({ error: err2.message });
            } else {
                res.json({ order_id: orderId, message: "Заказ оформлен!" });
            }
        });
    });
});

// 6. Получить заказы пользователя
app.get("/api/orders/:user_id", (req, res) => {
    const userId = req.params.user_id;
    
    const sql = `
        SELECT o.id, o.order_date, o.total_amount, o.status,
               oi.quantity, oi.price, p.name as product_name
        FROM orders o
        JOIN order_items oi ON o.id = oi.order_id
        JOIN products p ON oi.product_id = p.id
        WHERE o.user_id = ?
        ORDER BY o.order_date DESC
    `;
    
    connection.query(sql, [userId], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 7. Добавить отзыв
app.post("/api/reviews", (req, res) => {
    const { product_id, user_id, rating, comment } = req.body;
    
    const sql = `
        INSERT INTO reviews (product_id, user_id, rating, comment)
        VALUES (?, ?, ?, ?)
    `;
    
    connection.query(sql, [product_id, user_id, rating, comment], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ message: "Спасибо за отзыв!" });
        }
    });
});

// 8. Получить отзывы о товаре
app.get("/api/reviews/:product_id", (req, res) => {
    const productId = req.params.product_id;
    
    const sql = `
        SELECT r.rating, r.comment, r.created_at, u.username
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        WHERE r.product_id = ?
        ORDER BY r.created_at DESC
    `;
    
    connection.query(sql, [productId], (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(results);
        }
    });
});

// 9. Получить все отзывы (для страницы отзывов)
app.get("/api/reviews", (req, res) => {
    const sql = `
        SELECT r.id, r.rating, r.comment, r.created_at, 
               u.username, p.name AS product_name
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        JOIN products p ON r.product_id = p.id
        ORDER BY r.created_at DESC
    `;
    
    connection.query(sql, (err, results) => {
        if (err) {
            console.error("Ошибка получения отзывов:", err);
            res.status(500).json({ error: err.message });
        } else {
            console.log("Найдено отзывов:", results.length); 
            res.json(results);
        }
    });
});

app.listen(3000, () => {
    console.log("Сервер запущен на http://localhost:3000");
});