// 1. ПОЛУЧЕНИЕ ЭЛЕМЕНТОВ DOM
// Элементы для товаров
const productsDiv = document.getElementById("productsContainer");
// Элементы корзины
const cartCountSpan = document.getElementById("cartCount");
const cartItemsDiv = document.getElementById("cartItems");
const cartTotalSpan = document.getElementById("cartTotal");
const cartSidebar = document.getElementById("cartSidebar");
const cartIcon = document.getElementById("cartIcon");
const closeCart = document.getElementById("closeCart");
const checkoutBtn = document.getElementById("checkoutBtn");
// Модальные окна
const productModal = document.getElementById("productModal");
const loginModal = document.getElementById("loginModal");
const registerModal = document.getElementById("registerModal");
// Элементы профиля
const profileName = document.getElementById('profileName');
const profileEmail = document.getElementById('profileEmail');
const profilePhone = document.getElementById('profilePhone');
const profileAddress = document.getElementById('profileAddress');
const profileContainer = document.getElementById('profileContainer');
const guestMessage = document.getElementById('guestMessage');
// Элементы страницы отзывов
const reviewsContainer = document.getElementById('reviewsContainer');
const reviewFormContainer = document.getElementById('reviewFormContainer');
const guestReviewMessage = document.getElementById('guestReviewMessage');
const addReviewForm = document.getElementById('addReviewForm');
// Кнопки навигации
const burger = document.getElementById("burger");
const navMenu = document.getElementById("navMenu");
// Кнопки авторизации
const loginBtn = document.getElementById("loginBtn");
const registerBtn = document.getElementById("registerBtn");
const doLoginBtn = document.getElementById("doLoginBtn");
const doRegisterBtn = document.getElementById("doRegisterBtn");
const logoutBtn = document.getElementById("logoutBtn");
const guestLoginBtn = document.getElementById("guestLoginBtn");
// Поля ввода для логина
const loginUsername = document.getElementById("loginUsername");
const loginPassword = document.getElementById("loginPassword");
// Поля ввода для регистрации
const regUsername = document.getElementById("regUsername");
const regEmail = document.getElementById("regEmail");
const regPassword = document.getElementById("regPassword");
const regPassword2 = document.getElementById("regPassword2");
const regPhone = document.getElementById("regPhone");
const regAddress = document.getElementById("regAddress");

// Глобальные переменные
let cart = [];          // Хранилище товаров в корзине
let currentUser = null; // Текущий авторизованный пользователь

// 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
/**
 * Экранирование HTML-символов для безопасности (защита от XSS)
 */
function escapeHtml(text) {
    if (!text) return '';
    return text.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

/**
 * Показ всплывающего уведомления
 * @param {string} message - Текст уведомления
 * @param {string} type - Тип: 'success' или 'error'
 */
function showNotification(message, type = "success") {
    const notification = document.createElement("div");
    notification.className = "notification";
    notification.textContent = message;
    notification.style.background = type === "error" ? "#e74c3c" : "#7B2CBF";
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

/**
 * Закрытие модального окна по ID
 * @param {string} modalId - ID модального окна
 */
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove("active");
}

// 3. ФУНКЦИИ КОРЗИНЫ

/**
 * Обновление интерфейса корзины (счётчик, список, итоговая сумма)
 */
function updateCartUI() {
    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    if (cartCountSpan) cartCountSpan.textContent = totalCount;
    
    if (cartItemsDiv) {
        if (cart.length === 0) {
            cartItemsDiv.innerHTML = "<p>Корзина пуста</p>";
        } else {
            cartItemsDiv.innerHTML = "";
            cart.forEach(item => {
                cartItemsDiv.innerHTML += `
                <div class="cart-item">
                    <div class="cart-item-info">
                        <div class="cart-item-title">${escapeHtml(item.name)}</div>
                        <div class="cart-item-price">${item.price} ₽ x ${item.quantity}</div>
                        <div>Итого: ${item.price * item.quantity} ₽</div>
                        <button onclick="removeFromCart(${item.id})" style="margin-top: 5px;">Удалить</button>
                    </div>
                </div>
                `;
            });
        }
    }
    
    if (cartTotalSpan) {
        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        cartTotalSpan.textContent = total;
    }
    
    localStorage.setItem("cart", JSON.stringify(cart));
}

/**
 * Добавление товара в корзину
 * @param {number} id - ID товара
 * @param {string} name - Название товара
 * @param {number} price - Цена товара
 * @param {number} quantity - Количество (по умолчанию 1)
 */
function addToCart(id, name, price, quantity = 1) {
    const existing = cart.find(item => item.id === id);
    if (existing) {
        existing.quantity += quantity;
    } else {
        cart.push({ id, name, price, quantity });
    }
    updateCartUI();
    showNotification(`${name} добавлен в корзину!`);
}

/**
 * Удаление товара из корзины
 * @param {number} id - ID товара
 */
function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    updateCartUI();
    showNotification("Товар удалён из корзины");
}
/**
 * Открытие боковой панели корзины
 */
function openCartSidebar() {
    if (cartSidebar) cartSidebar.classList.add("open");
}
/**
 * Закрытие боковой панели корзины
 */
function closeCartSidebar() {
    if (cartSidebar) cartSidebar.classList.remove("open");
}
// 4. ФУНКЦИИ ДЛЯ ТОВАРОВ
/**
 * Загрузка и отображение всех товаров на странице
 */
async function loadProducts() {
    if (!productsDiv) return;
    
    try {
        const res = await fetch("/api/products");
        const products = await res.json();
        productsDiv.innerHTML = "";
        
        products.forEach(product => {
            productsDiv.innerHTML += `
            <div class="product-card" onclick="showProductModal(${product.id})">
                <div class="product-info">
                    <div class="product-title">${escapeHtml(product.name)}</div>
                    <div class="product-price">${product.price} ₽</div>
                    <button class="btn" onclick="event.stopPropagation(); addToCart(${product.id}, '${escapeHtml(product.name)}', ${product.price})">
                        В корзину
                    </button>
                </div>
            </div>
            `;
        });
    } catch (error) {
        console.error("Ошибка загрузки товаров:", error);
        productsDiv.innerHTML = "<p>Ошибка загрузки товаров</p>";
    }
}
/**
 * Показ модального окна с детальной информацией о товаре
 * @param {number} productId - ID товара
 */
function showProductModal(productId) {
    fetch(`/api/products/${productId}`)
        .then(res => res.json())
        .then(product => {
            const modalTitle = document.getElementById("modalTitle");
            const modalDesc = document.getElementById("modalDesc");
            const modalPrice = document.getElementById("modalPrice");
            const modalQuantity = document.getElementById("modalQuantity");
            
            if (modalTitle) modalTitle.textContent = product.name;
            if (modalDesc) modalDesc.textContent = product.description || "Освежающий напиток";
            if (modalPrice) modalPrice.textContent = product.price + " ₽";
            if (modalQuantity) modalQuantity.value = 1;
            
            if (productModal) productModal.classList.add("active");
            
            const modalAddBtn = document.getElementById("modalAddBtn");
            if (modalAddBtn) {
                const newBtn = modalAddBtn.cloneNode(true);
                modalAddBtn.parentNode.replaceChild(newBtn, modalAddBtn);
                newBtn.addEventListener("click", () => {
                    const quantity = parseInt(document.getElementById("modalQuantity")?.value || 1);
                    addToCart(product.id, product.name, product.price, quantity);
                    if (productModal) productModal.classList.remove("active");
                });
            }
        })
        .catch(error => console.error("Ошибка:", error));
}

// 5. ФУНКЦИИ АВТОРИЗАЦИИ
/**
 * Вход в аккаунт (логин)
 */
async function login() {
    const username = loginUsername?.value;
    const password = loginPassword?.value;
    
    if (!username || !password) {
        showNotification("Введите имя и пароль!", "error");
        return;
    }
    
    try {
        const res = await fetch("/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });
        
        const data = await res.json();
        
        if (res.ok) {
            currentUser = {
                id: data.id,
                username: data.username,
                email: data.email,
                phone: data.phone || '',
                address: data.address || ''
            };
            localStorage.setItem("user", JSON.stringify(currentUser));
            showNotification(`Добро пожаловать, ${data.username}!`);
            closeModal('loginModal');
            updateUserUI();
            
            // Очищаем поля входа
            if (loginUsername) loginUsername.value = '';
            if (loginPassword) loginPassword.value = '';
        } else {
            showNotification(data.error, "error");
        }
    } catch (error) {
        console.error("Ошибка входа:", error);
        showNotification("Ошибка соединения с сервером", "error");
    }
}

/**
 * Регистрация нового пользователя
 */
async function register() {
    const username = regUsername?.value;
    const email = regEmail?.value;
    const password = regPassword?.value;
    const password2 = regPassword2?.value;
    const phone = regPhone?.value || '';
    const address = regAddress?.value || '';
    
    if (!username || !email || !password) {
        showNotification("Заполните обязательные поля!", "error");
        return;
    }
    
    if (password !== password2) {
        showNotification("Пароли не совпадают!", "error");
        return;
    }
    
    try {
        const res = await fetch("/api/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, email, password, phone, address })
        });
        
        const data = await res.json();
        
        if (res.ok) {
            // Автоматически входим после регистрации
            currentUser = {
                id: data.id,
                username: data.username,
                email: data.email,
                phone: data.phone || phone,
                address: data.address || address
            };
            localStorage.setItem("user", JSON.stringify(currentUser));
            showNotification("Регистрация успешна! Вы вошли в аккаунт.");
            closeModal('registerModal');
            updateUserUI();
            
            // Очищаем форму регистрации
            if (regUsername) regUsername.value = '';
            if (regEmail) regEmail.value = '';
            if (regPassword) regPassword.value = '';
            if (regPassword2) regPassword2.value = '';
            if (regPhone) regPhone.value = '';
            if (regAddress) regAddress.value = '';
        } else {
            showNotification(data.error, "error");
        }
    } catch (error) {
        console.error("Ошибка регистрации:", error);
        showNotification("Ошибка соединения с сервером", "error");
    }
}

/**
 * Выход из аккаунта
 */
function logout() {
    currentUser = null;
    localStorage.removeItem("user");
    showNotification("Вы вышли из аккаунта");
    updateUserUI();
}

// 6. ФУНКЦИИ ПРОФИЛЯ И ЗАКАЗОВ
/**
 * Получение текстового описания статуса заказа
 * @param {string} status - Код статуса
 * @returns {string} - Текстовое описание
 */
function getStatusText(status) {
    const statuses = {
        'pending': 'В обработке',
        'confirmed': 'Подтверждён',
        'delivered': 'Доставлен',
        'cancelled': 'Отменён'
    };
    return statuses[status] || status;
}
/**
 * Загрузка и отображение заказов пользователя
 */
async function loadOrders() {
    const container = document.getElementById('ordersContainer');
    if (!container) return;
    
    if (!currentUser) {
        container.innerHTML = '<p>Войдите в аккаунт, чтобы увидеть заказы</p>';
        return;
    }
    
    try {
        const res = await fetch(`/api/orders/${currentUser.id}`);
        const orders = await res.json();
        
        if (orders.length === 0) {
            container.innerHTML = '<p>У вас пока нет заказов</p>';
        } else {
            // Группируем заказы по ID
            const groupedOrders = {};
            orders.forEach(order => {
                if (!groupedOrders[order.id]) {
                    groupedOrders[order.id] = {
                        id: order.id,
                        date: order.order_date,
                        total: order.total_amount,
                        status: order.status,
                        items: []
                    };
                }
                groupedOrders[order.id].items.push({
                    name: order.product_name,
                    quantity: order.quantity,
                    price: order.price
                });
            });
            
            container.innerHTML = Object.values(groupedOrders).map(order => `
                <div class="order-item">
                    <div>
                        <strong>Заказ №${order.id}</strong><br>
                        Дата: ${new Date(order.date).toLocaleDateString()}<br>
                        Статус: <span class="status-${order.status}">${getStatusText(order.status)}</span>
                    </div>
                    <div>
                        ${order.items.map(item => `
                            <div>${escapeHtml(item.name)} x ${item.quantity} = ${item.price * item.quantity} ₽</div>
                        `).join('')}
                        <strong>Итого: ${order.total} ₽</strong>
                    </div>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Ошибка загрузки заказов:', error);
        container.innerHTML = '<p>Ошибка загрузки заказов</p>';
    }
}
/**
 * Обновление интерфейса в зависимости от авторизации пользователя
 */
function updateUserUI() {
    const authButtons = document.querySelector(".auth-buttons");
    const userInfo = document.querySelector(".user-info");
    const usernameSpan = document.querySelector(".username");
    
    // Обновляем навигацию
    if (currentUser && authButtons && userInfo) {
        authButtons.style.display = "none";
        userInfo.style.display = "flex";
        if (usernameSpan) usernameSpan.textContent = currentUser.username;
        
        // Заполняем данные профиля
        if (profileName) profileName.textContent = currentUser.username;
        if (profileEmail) profileEmail.textContent = currentUser.email;
        if (profilePhone) profilePhone.textContent = currentUser.phone || 'Телефон: не указан';
        if (profileAddress) profileAddress.textContent = currentUser.address || 'Адрес: не указан';
        
        // Показываем профиль, скрываем сообщение для гостя
        if (profileContainer) profileContainer.style.display = 'block';
        if (guestMessage) guestMessage.style.display = 'none';
        
        // Загружаем заказы
        loadOrders();
        
    } else if (authButtons && userInfo) {
        authButtons.style.display = "flex";
        userInfo.style.display = "none";
        
        // Показываем сообщение для гостя, скрываем профиль
        if (profileContainer) profileContainer.style.display = 'none';
        if (guestMessage) guestMessage.style.display = 'block';
    }
    
    // Обновляем видимость формы отзыва
    updateReviewFormVisibility();
}

// 7. ФУНКЦИИ ЗАКАЗОВ
/**
 * Оформление заказа
 */
async function checkout() {
    if (!currentUser) {
        showNotification("Сначала войдите в аккаунт!", "error");
        if (loginModal) loginModal.classList.add("active");
        return;
    }
    
    if (cart.length === 0) {
        showNotification("Корзина пуста!", "error");
        return;
    }
    
    const address = prompt("Введите адрес доставки:");
    if (!address) return;
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const items = cart.map(item => ({
        product_id: item.id,
        quantity: item.quantity,
        price: item.price
    }));
    
    try {
        const res = await fetch("/api/orders", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                user_id: currentUser.id,
                items,
                total,
                address
            })
        });
        
        const data = await res.json();
        
        if (res.ok) {
            showNotification("Заказ оформлен!");
            cart = [];
            updateCartUI();
            closeCartSidebar();
            if (document.getElementById('ordersContainer')) {
                loadOrders();
            }
        } else {
            showNotification(data.error, "error");
        }
    } catch (error) {
        console.error("Ошибка оформления заказа:", error);
        showNotification("Ошибка соединения с сервером", "error");
    }
}
// 8. ФУНКЦИИ ДЛЯ ОТЗЫВОВ
/**
 * Загрузка и отображение всех отзывов
 */
async function loadReviews() {
    if (!reviewsContainer) return;
    
    try {
        const res = await fetch('/api/reviews');
        const reviews = await res.json();
        
        if (reviews.length === 0) {
            reviewsContainer.innerHTML = '<p style="text-align: center;">Пока нет отзывов. Будьте первым! 🎉</p>';
            return;
        }
        
        reviewsContainer.innerHTML = reviews.map(review => `
            <div class="review-card">
                <div class="review-header">
                    <span class="review-author">👤 ${escapeHtml(review.username)}</span>
                    <span class="review-product">${escapeHtml(review.product_name)}</span>
                </div>
                <div class="review-rating">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</div>
                <div class="review-comment">${escapeHtml(review.comment)}</div>
                <div class="review-date">${new Date(review.created_at).toLocaleDateString()}</div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Ошибка загрузки отзывов:', error);
        reviewsContainer.innerHTML = '<p>Ошибка загрузки отзывов</p>';
    }
}
/**
 * Загрузка товаров для выпадающего списка в форме отзыва
 */
async function loadProductsForReview() {
    const select = document.getElementById('reviewProductId');
    if (!select) return;
    
    try {
        const res = await fetch('/api/products');
        const products = await res.json();
        
        select.innerHTML = '<option value="">Выберите напиток</option>' +
            products.map(product => `<option value="${product.id}">${escapeHtml(product.name)} - ${product.price} ₽</option>`).join('');
    } catch (error) {
        console.error('Ошибка загрузки товаров:', error);
    }
}
/**
 * Обновление отображения звёзд рейтинга
 * @param {number} rating - Значение рейтинга (1-5)
 */
function updateStarsDisplay(rating) {
    const stars = document.querySelectorAll('.star');
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });
}
/**
 * Настройка интерактивных звёзд в форме отзыва
 */
function setupRatingStars() {
    const stars = document.querySelectorAll('.star');
    const ratingInput = document.getElementById('reviewRating');
    
    if (!stars.length) return;
    
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const rating = parseInt(star.dataset.rating);
            if (ratingInput) ratingInput.value = rating;
            updateStarsDisplay(rating);
        });
        
        star.addEventListener('mouseenter', () => {
            const rating = parseInt(star.dataset.rating);
            updateStarsDisplay(rating);
        });
        
        star.addEventListener('mouseleave', () => {
            const currentRating = parseInt(ratingInput?.value || 5);
            updateStarsDisplay(currentRating);
        });
    });
}
/**
 * Показ/скрытие формы отзыва в зависимости от авторизации
 */
function updateReviewFormVisibility() {
    if (reviewFormContainer && guestReviewMessage) {
        if (currentUser) {
            reviewFormContainer.style.display = 'block';
            guestReviewMessage.style.display = 'none';
        } else {
            reviewFormContainer.style.display = 'none';
            guestReviewMessage.style.display = 'block';
        }
    }
}
/**
 * Добавление нового отзыва
 */
async function addReview(productId, rating, comment) {
    if (!currentUser) {
        showNotification('Войдите в аккаунт, чтобы оставить отзыв!', 'error');
        return false;
    }
    
    if (!productId || !rating || !comment) {
        showNotification('Заполните все поля!', 'error');
        return false;
    }
    
    try {
        const res = await fetch('/api/reviews', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                product_id: parseInt(productId),
                user_id: currentUser.id,
                rating: parseInt(rating),
                comment: comment
            })
        });
        
        const data = await res.json();
        
        if (res.ok) {
            showNotification('Спасибо за отзыв!');
            
            // Очищаем форму
            const select = document.getElementById('reviewProductId');
            const commentTextarea = document.getElementById('reviewComment');
            const ratingInput = document.getElementById('reviewRating');
            
            if (select) select.value = '';
            if (commentTextarea) commentTextarea.value = '';
            if (ratingInput) ratingInput.value = '5';
            
            updateStarsDisplay(5);
            loadReviews();
            return true;
        } else {
            showNotification(data.error, 'error');
            return false;
        }
    } catch (error) {
        console.error('Ошибка добавления отзыва:', error);
        showNotification('Ошибка добавления отзыва', 'error');
        return false;
    }
}

// 9. НАСТРОЙКА ОБРАБОТЧИКОВ СОБЫТИЙ
// Корзина
if (cartIcon) cartIcon.addEventListener("click", openCartSidebar);
if (closeCart) closeCart.addEventListener("click", closeCartSidebar);
if (checkoutBtn) checkoutBtn.addEventListener("click", checkout);

// Бургер-меню
if (burger && navMenu) {
    burger.addEventListener("click", () => navMenu.classList.toggle("active"));
}

// Открытие модальных окон авторизации
if (loginBtn) {
    loginBtn.addEventListener("click", () => loginModal?.classList.add("active"));
}
if (registerBtn) {
    registerBtn.addEventListener("click", () => registerModal?.classList.add("active"));
}
if (guestLoginBtn) {
    guestLoginBtn.addEventListener("click", () => loginModal?.classList.add("active"));
}

// Кнопки действий в модальных окнах
if (doLoginBtn) {
    doLoginBtn.addEventListener("click", (e) => {
        e.preventDefault();
        login();
    });
}
if (doRegisterBtn) {
    doRegisterBtn.addEventListener("click", (e) => {
        e.preventDefault();
        register();
    });
}

// Кнопка выхода
if (logoutBtn) {
    logoutBtn.addEventListener("click", logout);
}

// Вход/регистрация по нажатию Enter
if (loginPassword) {
    loginPassword.addEventListener("keypress", (e) => {
        if (e.key === "Enter") login();
    });
}
if (regPassword2) {
    regPassword2.addEventListener("keypress", (e) => {
        if (e.key === "Enter") register();
    });
}

// Закрытие модальных окон по крестику
document.querySelectorAll(".close-modal, .close").forEach(btn => {
    btn.addEventListener("click", () => {
        productModal?.classList.remove("active");
        loginModal?.classList.remove("active");
        registerModal?.classList.remove("active");
    });
});

// Закрытие модальных окон по клику вне окна
window.addEventListener("click", (e) => {
    if (e.target === productModal) productModal?.classList.remove("active");
    if (e.target === loginModal) loginModal?.classList.remove("active");
    if (e.target === registerModal) registerModal?.classList.remove("active");
});

// Переключение между модальными окнами
const switchToRegister = document.getElementById("switchToRegister");
const switchToLogin = document.getElementById("switchToLogin");

if (switchToRegister) {
    switchToRegister.addEventListener("click", (e) => {
        e.preventDefault();
        loginModal?.classList.remove("active");
        registerModal?.classList.add("active");
    });
}
if (switchToLogin) {
    switchToLogin.addEventListener("click", (e) => {
        e.preventDefault();
        registerModal?.classList.remove("active");
        loginModal?.classList.add("active");
    });
}

// 10. ЗАГРУЗКА ДАННЫХ ПРИ СТАРТЕ СТРАНИЦЫ
// Загрузка корзины из localStorage
const savedCart = localStorage.getItem("cart");
if (savedCart) cart = JSON.parse(savedCart);
updateCartUI();

// Загрузка пользователя из localStorage
const savedUser = localStorage.getItem("user");
if (savedUser) currentUser = JSON.parse(savedUser);
updateUserUI();

// Загрузка товаров (если есть контейнер)
if (productsDiv) loadProducts();

// 11. ИНИЦИАЛИЗАЦИЯ ДЛЯ СТРАНИЦЫ ОТЗЫВОВ
if (reviewsContainer) {
    loadReviews();
    loadProductsForReview();
    setupRatingStars();
    updateReviewFormVisibility();
    
    // Обработчик отправки формы отзыва
    if (addReviewForm) {
        addReviewForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const productId = document.getElementById('reviewProductId')?.value;
            const rating = document.getElementById('reviewRating')?.value;
            const comment = document.getElementById('reviewComment')?.value;
            await addReview(productId, rating, comment);
        });
    }
    
    // Кнопки для гостей
    const reviewLoginBtn = document.getElementById('reviewLoginBtn');
    const reviewRegisterBtn = document.getElementById('reviewRegisterBtn');
    
    if (reviewLoginBtn) {
        reviewLoginBtn.addEventListener('click', (e) => {
            e.preventDefault();
            loginModal?.classList.add('active');
        });
    }
    if (reviewRegisterBtn) {
        reviewRegisterBtn.addEventListener('click', (e) => {
            e.preventDefault();
            registerModal?.classList.add('active');
        });
    }
}