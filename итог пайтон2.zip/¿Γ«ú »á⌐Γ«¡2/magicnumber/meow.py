number = int(input("Введите трёхзначное число: "))

a = number // 100           
b = (number // 10) % 10     
c = number % 10             

sum = a + b + c
product = a * b * c
result = product - sum

print(f"Результат: {product} - {sum} = {result}")