weight = float(input("Введите ваш вес (кг): "))
height_cm = float(input("Введите ваш рост (см): "))

height_m = height_cm / 100

bmi = weight / (height_m ** 2)

bmi_rounded = round(bmi, 1)

print(f"Ваш ИМТ: {bmi_rounded}")