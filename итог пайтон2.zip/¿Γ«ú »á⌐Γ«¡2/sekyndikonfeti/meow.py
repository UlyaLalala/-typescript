# sekyndi
seconds = 155

# Расчет
minutes = seconds // 60    
remaining_seconds = seconds % 60   

# Вывод
print(f"{seconds} секунд -> {minutes} минут и {remaining_seconds} секунд")

# konfeti
candies = 20
friends = 3

candies_per_friend = candies // friends  
remaining_candies = candies % friends      

print(f"Всего конфет: {candies}")
print(f"Количество друзей: {friends}")
print("-" * 30)
print(f"Каждому другу достанется: {candies_per_friend} конфет")
print(f"Останется : {remaining_candies} конфет")