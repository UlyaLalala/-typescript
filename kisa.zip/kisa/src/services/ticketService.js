// src/services/ticketService.js
const store = require('./store');

const PRIORITY_WEIGHT = { high: 3, medium: 2, low: 1 };

const ALLOWED_PRIORITIES = ['low', 'medium', 'high'];

function getAll(filter = {}) {
  let result = [...store];

  if (filter.priority) {
    result = result.filter(t => t.priority === filter.priority);
  }

  result.sort((a, b) => PRIORITY_WEIGHT[b.priority] - PRIORITY_WEIGHT[a.priority]);

  return result;
}

function getById(id) {
  return store.find(t => t.id === id) || null;
}

function create(data) {
  const newId = store.length ? Math.max(...store.map(t => t.id)) + 1 : 1;
  const newTicket = {
    id: newId,
    title: data.title,
    priority: data.priority,
    status: data.status || 'open',
  };
  store.push(newTicket);
  return newTicket;
}

function update(id, data) {
  const ticket = getById(id);
  if (!ticket) return null;
  ticket.title = data.title;
  ticket.priority = data.priority;
  ticket.status = data.status || 'open';
  return ticket;
}

function patch(id, data) {
  const ticket = getById(id);
  if (!ticket) return null;
  if (data.title !== undefined)    ticket.title = data.title;
  if (data.priority !== undefined) ticket.priority = data.priority;
  if (data.status !== undefined)   ticket.status = data.status;
  return ticket;
}

function remove(id) {
  const index = store.findIndex(t => t.id === id);
  if (index === -1) return false;
  store.splice(index, 1);
  return true;
}

module.exports = {
  getAll, 
  getById, 
  create, update, 
  patch, remove,
  ALLOWED_PRIORITIES,
};