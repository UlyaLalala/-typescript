let tickets = [
    { id: 1, 
      title: 'Проблема с входом', 
      priority: 'low' 
    },

    { id: 2, 
      title: 'Срочная ошибка сервера', 
      priority: 'high' },

    { id: 3, 
      title: 'Медленная загрузка', 
      priority: 'medium' }
];

