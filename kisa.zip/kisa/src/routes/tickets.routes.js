const express = require('express');
const router = express.Router();
const controller = require('../controllers/ticketController');
const { validateFull, validatePartial } = require('../middlewares/validateTicket');

router.get('/',        controller.getAll);
router.get('/:id',     controller.getOne);
router.post('/',       validateFull,    controller.create);
router.put('/:id',     validateFull,    controller.update);
router.patch('/:id',   validatePartial, controller.patch);
router.delete('/:id',  controller.remove);

module.exports = router;