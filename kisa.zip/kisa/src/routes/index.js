const express = require('express')
const carRouter = require('./tickets.routes')

const router = express.Router()

router.use('/tickets', carRouter)
module.exports = router