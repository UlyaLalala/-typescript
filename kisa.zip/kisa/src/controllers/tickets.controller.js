const service = require('../services/ticketService');

exports.getAll = (req, res, next) => {
  try {
    const { priority } = req.query;
    const tickets = service.getAll({ priority });
    res.status(200).json(tickets);
  } catch (err) { next(err); }
};

exports.getOne = (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const ticket = service.getById(id);
    if (!ticket) {
      return res.status(404).json({ error: `Заявка с id=${id} не найдена` });
    }
    res.status(200).json(ticket);
  } catch (err) { next(err); }
};

exports.create = (req, res, next) => {
  try {
    const ticket = service.create(req.body);
    res.status(201).json(ticket);
  } catch (err) { next(err); }
};

exports.update = (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const ticket = service.update(id, req.body);
    if (!ticket) {
      return res.status(404).json({ error: `Заявка с id=${id} не найдена` });
    }
    res.status(200).json(ticket);
  } catch (err) { next(err); }
};

exports.patch = (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const ticket = service.patch(id, req.body);
    if (!ticket) {
      return res.status(404).json({ error: `Заявка с id=${id} не найдена` });
    }
    res.status(200).json(ticket);
  } catch (err) { next(err); }
};

exports.remove = (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const ok = service.remove(id);
    if (!ok) {
      return res.status(404).json({ error: `Заявка с id=${id} не найдена` });
    }
    res.status(204).send(); 
  } catch (err) { next(err); }
};