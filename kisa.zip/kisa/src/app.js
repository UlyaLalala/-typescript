const express = require('express');
const ticketRoutes = require('./routes/ticketRoutes');
const notFound = require('./middlewares/notFound');
const errorHandler = require('./middlewares/errorHandler');

const app = express();

app.use(express.json());
app.use('/tickets', ticketRoutes);
app.use(notFound);
app.use(errorHandler);

module.exports = app;