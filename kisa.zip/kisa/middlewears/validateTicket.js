const { ALLOWED_PRIORITIES } = require('../services/ticketService');

function validateFull(req, res, next) {
  const { title, priority } = req.body || {};
  const errors = [];

  if (!title || typeof title !== 'string' || title.trim() === '') {
    errors.push('Поле "title" обязательно и должно быть непустой строкой');
  }

  if (!priority || !ALLOWED_PRIORITIES.includes(priority)) {
    errors.push('Поле "priority" обязательно и должно быть одним из: low, medium, high');
  }

  if (errors.length) {
    return res.status(400).json({ error: 'Ошибка валидации', details: errors });
  }
  next();
}

function validatePartial(req, res, next) {
  const { title, priority } = req.body || {};
  const errors = [];

  if (title !== undefined && (typeof title !== 'string' || title.trim() === '')) {
    errors.push('Поле "title", если передано, должно быть непустой строкой');
  }

  if (priority !== undefined && !ALLOWED_PRIORITIES.includes(priority)) {
    errors.push('Поле "priority", если передано, должно быть одним из: low, medium, high');
  }

  if (errors.length) {
    return res.status(400).json({ error: 'Ошибка валидации', details: errors });
  }
  next();
}

module.exports = { validateFull, validatePartial };