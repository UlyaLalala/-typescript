module.exports = (err, req, res, next) => {
  console.error('[errorHandler]', err);
  const status = err.status || 500;
  res.status(status).json({
    error: err.message || 'Внутренняя ошибка сервера',
  });
};