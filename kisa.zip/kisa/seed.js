const store = require('./services/store');

function seed() {
  const initial = [
    { id: 1, 
      title: 'Проблема с интернетом',    
      priority: 'low',    
      status: 'open' 
    },
    { id: 2, 
      title: 'Срочный сбой сервера',     
      priority: 'high',   
      status: 'open' 
    },
    { id: 3, 
      title: 'Обновить ПО',              
      priority: 'medium', 
      status: 'in_progress' 
    },
    { id: 4, 
      title: 'Не работает принтер',      
      priority: 'low',    
      status: 'open' },
    { id: 5, 
      title: 'Утечка данных в отчёте',   
      priority: 'high',   
      status: 'open' 
    },
  ];
  store.push(...initial);
  console.log(`[seed] Добавлено ${initial.length} стартовых заявок`);
}

module.exports = seed;