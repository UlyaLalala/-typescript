month = int(input("Введите номер месяца (1-12): "))

if month == 12 or month == 1 or month == 2:
    print("Зима")
elif month == 3 or month == 4 or month == 5:
    print("Весна")
elif month == 6 or month == 7 or month == 8:
    print("Лето")
elif month == 9 or month == 10 or month == 11:
    print("Осень")
else:
    print("Неверный номер месяца")