number = int(input("Введите целое число: "))

if number % 2 == 0:
    print("Четное")
else:
    print("Нечетное")
    