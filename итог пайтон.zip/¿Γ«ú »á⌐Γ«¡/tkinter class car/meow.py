class Car:
    def __init__(self, brand, model, fuel):
        
        self.brand = brand          
        self.model = model          
        self.fuel = fuel           
        self.max_fuel = 60          
        self.is_engine_on = False   
    
    def start_engine(self) -> str:
        if self.is_engine_on:
            return f"Двигатель уже запущен. {self.brand} {self.model} готов к движению!"
        
        if self.fuel <= 0:
            return f"закончилось топливо заправьте {self.brand} {self.model}."
        
        self.is_engine_on = True
        return f"Двигатель {self.brand} {self.model} запущен. Уровень топлива: {self.fuel:.1f} л."
    
    def stop_engine(self) -> str:
        if not self.is_engine_on:
            return f"Двигатель {self.brand} {self.model} уже выключен."
        
        self.is_engine_on = False
        return f"Двигатель {self.brand} {self.model} выключен. Уровень топлива: {self.fuel:.1f} л."
    
    def drive(self, distance: float, fuel_consumption: float = 10) -> str:
        
        if not self.is_engine_on:
            return f"Невозможно поехать: двигатель {self.brand} {self.model} выключен."
        
        if distance <= 0:
            return f"Расстояние должно быть больше 0."
        
        needed_fuel = (distance / 100) * fuel_consumption
        
        if needed_fuel > self.fuel:
            max_possible_distance = (self.fuel / fuel_consumption) * 100
            return (f"Недостаточно топлива для поездки на {distance} км"
                   f"Максимально возможное расстояние: {max_possible_distance:.1f} км"
                   f"Текущий уровень топлива: {self.fuel:.1f} л.")
        
        self.fuel -= needed_fuel
        return (f"{self.brand} {self.model} проехал {distance} км"
               f"Расход топлива: {needed_fuel:.2f} л."
               f"Остаток топлива: {self.fuel:.1f} л")
    
    def refuel(self, amount: float) -> str:
 
        if amount <= 0:
            return f"Количество топлива для заправки должно быть больше 0"
        
        space_left = self.max_fuel - self.fuel
        if space_left <= 0:
            return f"Бак {self.brand} {self.model} полный. Текущий уровень: {self.fuel:.1f}/{self.max_fuel} л."
        
        if amount > space_left:
            old_fuel = self.fuel
            self.fuel = self.max_fuel
            return (f"Бак {self.brand} {self.model} заправлен максимально\n"
                   f"Хотели залить: {amount} л, но место только для {space_left} л. "
                   f"Залито: {space_left} л. Текущий уровень: {self.fuel:.1f}/{self.max_fuel} л.")
        
        self.fuel += amount
        return f"{self.brand} {self.model} заправлен на {amount} л. Текущий уровень: {self.fuel:.1f}/{self.max_fuel} л."
    
    def get_fuel_level(self) -> str:
        return f"Уровень топлива {self.brand} {self.model}: {self.fuel:.1f}/{self.max_fuel} л."
    
    def get_status(self) -> str:
        engine_status = "ВКЛЮЧЁН" if self.is_engine_on else "ВЫКЛЮЧЕН"
        return (f"Автомобиль: {self.brand} {self.model}\n"
               f"Двигатель: {engine_status}\n"
               f"Топливо: {self.fuel:.1f}/{self.max_fuel} л.\n"
               f"{'Готов к поездке!' if self.is_engine_on and self.fuel > 0 else 'Требуется запуск двигателя и/или заправка'}")

if __name__ == "__main__":
    print("=" * 60)
    print("тестирование класса")
    print("=" * 60)
    
    # Создаём автомобиль
    my_car = Car("Toyota", "Camry", 25)
    
    print("\nсостояние после создания:")
    print(my_car.get_status())
    
    print("\nуехать без запуска двигателя:")
    print(my_car.drive(50))
    
    print("\nзапуск двигателя:")
    print(my_car.start_engine())
    
    print("\nуехать с запущенным двигателем:")
    print(my_car.drive(200))  
    
    print("\nостановка двигателя:")
    print(my_car.stop_engine())
    
    print("\nзаправка:")
    print(my_car.refuel(40))  
    
    print("\nзапуск двигателя:")
    print(my_car.start_engine())
    
    print("\nдоступное расстояние:")
    print(my_car.drive(100))  
    
    print("\nуровень топлива:")
    print(my_car.get_fuel_level())
    
    print("\nсостояние:")
    print(my_car.get_status())
    
    