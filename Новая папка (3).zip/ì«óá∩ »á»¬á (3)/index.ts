import express, { Request, Response } from "express";

type Priority = "low" | "medium" | "high";
type Status = "open" | "in_progress" | "closed";

interface Ticket {
  id: number;
  title: string;
  priority: Priority;
  status: Status;
}

interface ErrorResponse {
  error: string;
}

const tickets: Ticket[] = [
  { id: 1, title: "Проблема с интернетом",  priority: "low",    status: "open" },
  { id: 2, title: "Срочный сбой сервера",   priority: "high",   status: "open" },
  { id: 3, title: "Обновить ПО",            priority: "medium", status: "in_progress" },
  { id: 4, title: "Не работает принтер",    priority: "low",    status: "open" },
  { id: 5, title: "Утечка данных в отчёте", priority: "high",   status: "open" },
];

const app = express();
app.use(express.json());

app.get(
  "/tickets",
  (
    req: Request<{}, Ticket[], {}, { priority?: Priority }>,
    res: Response<Ticket[]>
  ) => {
    const { priority } = req.query;
    const result = priority
      ? tickets.filter((t) => t.priority === priority)
      : tickets;
    res.json(result);
  }
);

app.get(
  "/tickets/:id",
  (
    req: Request<{ id: string }>,
    res: Response<Ticket | ErrorResponse>
  ) => {
    const id = Number(req.params.id);
    if (Number.isNaN(id)) {
      res.status(400).json({ error: "id не число" });
      return;
    }
    const ticket = tickets.find((t) => t.id === id);
    if (!ticket) {
      res.status(404).json({ error: "Заявка не найдена" });
      return;
    }
    res.json(ticket);
  }
);

const PORT = Number(process.env.PORT) || 3000;
app.listen(PORT, () =>
console.log(`Сервер запущен: http://localhost:${PORT}`));